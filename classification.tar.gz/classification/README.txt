###################################################### Generate_Features.py ##########################################################
Download Twitter POS tagger and set the path need to be set in line 32.
python Generate_Features.py sample_input.txt sample_output.txt


##################################################### Future_Classifier.py ############################################################
This code can classify future data using previously developed model DISMODEL.pkl
Download Twitter POS tagger and set the path need to be set in line 52.
python Future_Classifier.py <input file> <output file>
Sample input file is there: hydb_sample_input.txt
input file format: date \t tid \t uid \t tweet
output file: date \t tid \t uid \t tweet \t label \t confidence score [label = 1 => situational; label = 2 => non-situational]
