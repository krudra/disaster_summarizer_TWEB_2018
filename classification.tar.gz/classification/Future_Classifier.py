'''
Created on 11-May-2017

@author: Koustav
'''

import sys
import re
import codecs
import string
import os
from textblob import *
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn import metrics
from sklearn.linear_model import *
from sklearn import cross_validation
import gzip
from sklearn.externals import joblib
from happyfuntokenizing import *
import numpy as np
#from happyfuntokenizing import *

lmtzr = WordNetLemmatizer()
mycompile = lambda pat:  re.compile(pat,  re.UNICODE)

PRONOUN_PATH = 'classifier_disctionary/english_pronoun.txt'
WHWORD_PATH = 'classifier_dictionary/english_whwords.txt'
SLANG_PATH = 'classifier_dictionary/english_swear.txt'
INTENSIFIER_PATH = 'classifier_dictionary/english_intensifier.txt'
SUBJECTIVE_PATH = 'classifier_dictionary/subjclueslen1-HLTEMNLP05.tff'
EVENT_PATH = 'classifier_dictionary/english_nonsituational_phrase.txt'
MODAL_VERB_PATH = 'classifier_dictionary/english_modal_verb.txt'
RELIGION_PATH = 'classifier_dictionary/communal_race.txt'

emoticon_string = r"""
    (?:
      [<>]?
      [:;=8]                     # eyes
      [\-o\*\']?                 # optional nose
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth      
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth
      [\-o\*\']?                 # optional nose
      [:;=8]                     # eyes
      [<>]?
    )"""

TAGGER_PATH = ''

PRONOUN = {}
WHWORD = {}
SLANG = {}
INTENSIFIER = {}
SUBJECTIVE = {}
EVENT = {}
MODAL = {}
RELIGION = {}

def READ_FILES():

	fp = open(PRONOUN_PATH,'r')
        for l in fp:
		PRONOUN[l.strip(' \t\n\r').lower()] = 1
        fp.close()
	
	fp = open(INTENSIFIER_PATH,'r')
        for l in fp:
		INTENSIFIER[l.strip(' \t\n\r').lower()] = 1
        fp.close()
	
	fp = open(WHWORD_PATH,'r')
        for l in fp:
		WHWORD[l.strip(' \t\n\r').lower()] = 1
        fp.close()
	
	fp = open(SLANG_PATH,'r')
        for l in fp:
		SLANG[l.strip(' \t\n\r').lower()] = 1
        fp.close()

	fp = open(EVENT_PATH,'r')
        for l in fp:
		EVENT[l.strip(' \t\n\r').lower()] = 1
        fp.close()
	
	fp = open(MODAL_VERB_PATH,'r')
        for l in fp:
		MODAL[l.strip(' \t\n\r').lower()] = 1
        fp.close()
	
	fp = open(RELIGION_PATH,'r')
        for l in fp:
		RELIGION[l.strip(' \t\n\r').lower()] = 1
        fp.close()

	fp = open(SUBJECTIVE_PATH,'r')
        for l in fp:
                wl = l.split()
                x = wl[0].split('=')[1].strip(' \t\n\r')
                if x=='strongsubj':
                        y = wl[2].split('=')[1].strip(' \t\n\r')
                        SUBJECTIVE[y.lower()] = 1
	fp.close()

############################ This Functions are used #############################################

def emoticons(s):
        return len(re.findall(u'[\U0001f600-\U0001f60f\U0001f617-\U0001f61d\U0001f632\U0001f633\U0001f638-\U0001f63e\U0001f642\U0001f646-\U0001f64f\U0001f612\U0001f613\U0001f615\U0001f616\U0001f61e-\U0001f629\U0001f62c\U0001f62d\U0001f630\U0001f631\U0001f636\U0001f637\U0001f63c\U0001f63f-\U0001f641\U0001f64d]', s))

def smileys(s):
        return len(re.findall(r':\-\)|:[\)\]\}]|:[dDpP]|:3|:c\)|:>|=\]|8\)|=\)|:\^\)|:\-D|[xX8]\-?D|=\-?D|=\-?3|B\^D|:\'\-?\)|>:\[|:\-?\(|:\-?c|:\-?<|:\-?\[|:\{|;\(|:\-\|\||:@|>:\(|:\'\-?\(|D:<?|D[8;=X]|v.v|D\-\':|>:[\/]|:\-[./]|:[\/LS]|=[\/L]|>.<|:\$|>:\-?\)|>;\)|\}:\-?\)|3:\-?\)|\(>_<\)>?|^_?^;|\(#\^.\^#\)|[Oo]_[Oo]|:\-?o',s))

def getNumberOfElongatedWords(s):
    return len(re.findall('([a-zA-Z])\\1{2,}', s))
    
def pronoun(sen):
	
	for x in sen:
		if PRONOUN.__contains__(x)==True:
			return 1
	return 0

def exclamation(s):
	c = len(re.findall(r"[!]", s))
	if c>=1:
		return 1
	return 0

def question(s):
	return len(re.findall(r"[?]", s))

def intensifier(sen):

	count = 0
	for x in sen:
		if INTENSIFIER.__contains__(x)==True:
			count+=1
			#return 1
	if count>0:
		return 1
	return 0

def whword(sen):
	
	for x in sen:
		if WHWORD.__contains__(x)==True:
			return 1
	return 0

def religion(sen):
	
	for x in sen:
		if RELIGION.__contains__(x)==True:
			return 1
	return 0

def slang(sen):
	
	for x in sen:
		if SLANG.__contains__(x)==True:
			return 1
	return 0

def event_phrase(sen):
	
	for x in sen:
		if EVENT.__contains__(x)==True:
			return 1
	return 0

def getHashtagopinion(sen):
	fp = codecs.open(OPINION_HASHTAG_PATH,'r','utf-8')
	temp = set([])
	for l in fp:
		temp.add(l.strip(' \t\n\r').lower())
	fp.close()

	cur_hash = set([])
	for x in sen:
		if x.startswith('#')==True:
			cur_hash.add(x.strip(' \t\n\r').lower())
	size = len(temp.intersection(cur_hash))
	if size>0:
		return 1
	return 0

def numeral(temp):
	c = 0
	for x in temp:
		if x.isdigit()==True:
			c+=1
	return c

def modal(sen):
	for x in sen:
		if MODAL.__contains__(x)==True:
			return 1
	return 0

def subjectivity(sen):
	
        c = 0
        for x in sen:
                if SUBJECTIVE.__contains__(x)==True:
                        c+=1
        tot = len(sen) + 4.0 - 4.0 - 1.0
        num = c + 4.0 - 4.0
	try:
        	s = round(num/tot,4)
	except:
		s = 0
	if c>0:
		return c
	return 0
	#print(s)
	#return s

            
if __name__ == '__main__':

	READ_FILES()
	tok = Tokenizer(preserve_case=False)
	train_clf = joblib.load('DISMODEL.pkl')

	fo = open('temp.txt','w')
	fp = open(sys.argv[1],'r')
	for l in fp:
		wl = l.split('\t')
		fo.write(wl[3].strip(' \t\n\r') + '\n')
	fp.close()
	fo.close()

	command = TAGGER_PATH + '/./runTagger.sh --output-format conll temp.txt > tagfile.txt'
	os.system(command)
	
	fp = open('tagfile.txt','r')
	fs = open(sys.argv[1],'r')
	s = ''
	N = 0
	feature = []
	label = []
	for l in fp:
		wl = l.split('\t')
		if len(wl)>1:
			word = wl[0].strip(' \t\n\r').lower()
			tag = wl[1].strip(' \t\n\r')
			if tag=='N':
				try:
					w = lmtzr.lemmatize(word)
					word = w
				except Exception as e:
					pass
			elif tag=='V':
				try:
                                	w = Word(word)
                                	x = w.lemmatize("v")
					word = x
				except Exception as e:
                                	pass
			elif tag=='$':
				N+=1
			else:
				pass
			try:
				s = s + word + ' '
			except Exception as e:
				pass
		else:
			unigram = tok.tokenize(s)
			bigram = []
			trigram = []
			if len(unigram)>1:
				for i in range(0,len(unigram)-1,1):
					s = unigram[i] + ' ' + unigram[i+1]
					bigram.append(s)
			if len(unigram)>2:
				for i in range(0,len(unigram)-2,1):
					s = unigram[i] + ' ' + unigram[i+1] + ' ' + unigram[i+2]
					trigram.append(s)
			Ngram = unigram + bigram + trigram
			row = fs.readline().split('\t')
			temp = tok.tokenize(row[3])
			New = []
			if len(temp)>1:
				for i in range(0,len(temp)-1,1):
					s = temp[i] + ' ' + temp[i+1]
					New.append(s)
			if len(temp)>2:
				for i in range(0,len(temp)-2,1):
					s = temp[i] + ' ' + temp[i+1] + ' ' + temp[i+2]
					New.append(s)
			
			Ngram = Ngram + temp + New
			Ngram = set(Ngram)
			Ngram = list(Ngram)
			#print(Ngram)
			#sys.exit(0)
			E = exclamation(row[3])
			Q = question(row[3])
			M = modal(Ngram)
			I = intensifier(Ngram)
			W = whword(Ngram)
			EP = event_phrase(Ngram)
			S = subjectivity(temp)
			SG = slang(Ngram)
			P = pronoun(Ngram)
			EL = getNumberOfElongatedWords(row[3])
			RL = religion(Ngram)
			#EM = emoticons(org_tweet[row[1].strip(' \t\n\r')])
			#SM = smileys(row[0].strip(' \t\n\r'))
			#t = [N,E,Q,M,I,W,S,P,EP,SG,EM,SM]
			#t = [N,E,Q,M,I,W,S,P,EP,SG,EL]
			t = [N,E,Q,M,I,W,S,P,EP,SG,RL]
			feature.append(t)
			label.append(int(row[4]))
			N = 0
			s = ''
	fp.close()
	fs.close()

	predicted_label = train_clf.predict(feature)
        predicted_proba = train_clf.predict_proba(feature)

        fp = open(sys.argv[1],'r')
        fo = open(sys.argv[2],'w')
        index = 0
        for l in fp:
                wl = l.split('\t')
                s = wl[0].strip(' \t\n\r') + '\t' + wl[1].strip(' \t\n\r') + '\t' + wl[2].strip(' \t\n\r') + '\t' + wl[3].strip(' \t\n\r') + '\t' + str(predicted_label[index]) + '\t' + str(max(predicted_proba[index]))
                fo.write(s + '\n')
                index+=1
        fp.close()
        fo.close()
