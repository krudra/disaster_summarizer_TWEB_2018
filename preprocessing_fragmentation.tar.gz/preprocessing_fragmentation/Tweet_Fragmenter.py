import sys
import os
import string
import codecs
import aspell
from nltk.corpus import stopwords

cachedstopwords = stopwords.words("english")
ASPELL = aspell.Speller('lang', 'en')

Tagger_Path = '../Lexical_Resources/ark-tweet-nlp-0.3.2/'
Event = ['hydb','utkd','sandy_hook','hagupit','nepal','harda']
def split_tweet(ifname,ofname):
	
	fs = codecs.open(ifname,'r','utf-8')
	fo = codecs.open('temp.txt','w','utf-8')
	for l in fs:
		wl = l.split('\t')
		fo.write(wl[3].strip(' \t\n\r')+'\n')
	fs.close()
	fo.close()

	command = Tagger_Path + './runTagger.sh --output-format conll temp.txt > tag.txt'
	os.system(command)

	fs = codecs.open(ifname,'r','utf-8')
	fp = codecs.open('tag.txt','r','utf-8')
	fo = codecs.open(ofname,'w','utf-8')
	TAGREJECT = ['~','@','U','E']
	s = ''
	last = ('','')
	temp = []
	for l in fp:
		wl = l.split()
		if len(wl)>1:
			word = wl[0].strip(' #\t\n\r')
			tag = wl[1].strip(' \t\n\r')	
			if wl[1].strip(' \t\n\r') not in TAGREJECT:
				if tag==',':
					if word.startswith('!')==True or word.startswith('?')==True:
						s = s + word + ' '
						temp.append(s)
						s = ''
						last = (word,tag)
					elif word=='.':
						s = s + word + ' '
						temp.append(s)
						s = ''
						last = (word,tag)
					elif word!='.':
						if s.endswith('. ')==False and s.endswith(', ')==False and len(s)>0:
							s = s + ',' + ' '
							last = (word,tag)
					else:
						pass
				else:
					if tag!='#':
						s = s + word + ' '
						last = (word,'N')
					else:
						if last[1]!='#' and last[1]!=',' and last[0]!='.' and last[0]!='' and ASPELL.check(word)==1:
							s = s + word + ' '
							last = (word,'#')
						else:
							last = (word,tag)
			else:
				pass
		else:
			if len(s.split())>0:
				t = s.strip(' \t\n\r,.') + ' .'
				temp.append(t)
			pl = fs.readline().split('\t')
			FINAL = []
			for x in temp:
				if check(x)==1:
					s = pl[0].strip(' \t\n\r') + '\t' + pl[1].strip(' \t\n\r') + '\t' + pl[2].strip(' \t\n\r') + '\t' + x.strip(' ,\t\n\r:')
					FINAL.append(s)
			temp = []
			s = ''
			last = ('','')
			if len(FINAL)>0:
				for x in FINAL:
					fo.write(x+'\n')

	fp.close()
	fs.close()
	fo.close()

def check(x):
	text = x.split()
	flag = 0
	punctuation = string.punctuation
	for y in text:
		if y!='rt' and y!='mt' and y.startswith('#')==False and y.startswith('@')==False and y.startswith('http:')==False and y.startswith('https:')==False and y not in punctuation and y.startswith('!')==False and y.startswith('.')==False and y.startswith('?')==False:
			flag+=1
	if flag>=5:
		return 1
	return 0

def main():
	try:
		_, ifname, ofname = sys.argv
	except Exception as e:
		print(e)
		sys.exit(0)
	split_tweet(ifname,ofname)

if __name__=='__main__':
	main()
