How to run
--------------------
python Tweet_Fragmenter.py <input> <output>

Input file: Date \t Tweet ID \t User ID \t Tweet
Output file: Date \t Tweet ID \t User ID \t Fragment

Sample: python Tweet_Fragmenter.py hydb_RAW_TWEET.txt hydb_FRAGMENTED_TWEET.txt
