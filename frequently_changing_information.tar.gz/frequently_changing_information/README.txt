Contains location specific updates based on key verbs

How to run: python Anomaly_Detection.py <parsefile> <placefile> <output>

Sample run: python Anomaly_Detection.py hydb_parsed.txt hydb_place.txt hydb_numeric_variation.txt

Note: 

1. Based on particular requirement like 'killed people', 'died people', 'stranded people', following lines (63 -- 66) in the code can be updated.

2. Download Twitter POS tagger and set its path in line no. 34.
