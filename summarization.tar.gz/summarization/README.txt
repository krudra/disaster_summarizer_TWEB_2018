This directory contains two summarization codes

1. COWTS: COntent Word based Tweet Summarization proposed in CIKM'15. [Koustav Rudra, Subham Ghosh, Niloy Ganguly, Pawan Goyal, and Saptarshi Ghosh. 2015. Extracting Situational Information from Microblogs during Disaster Events: a Classification-Summarization Approach. In Proceedings of the 24th ACM International on Conference on Information and Knowledge Management (CIKM '15). ACM, New York, NY, USA, 583-592. DOI: https://doi.org/10.1145/2806416.2806485 ]

2. SEMCOWTS: SEMantic relation based COntent Word Tweet Summarization published in this paper. This is an extension of COWTS. [Koustav Rudra, Niloy Ganguly, Pawan Goyal, and Saptarshi Ghosh. 2018. Extracting and Summarizing Situational Information from the Twitter Social Media during Disasters. ACM Trans. Web 12, 3, Article 17 (July 2018), 35 pages. DOI: https://doi.org/10.1145/3178541]

Summarization codes and readmes are there for both the methods. Individual directories contain details about how to run those codes. If you use any of them kindly cite appropriate version.
