python content_word_extraction.py hydb_SITUATIONAL.txt hydb_place.txt hydb_CONTENT.txt
python NSEMCOWTS.py hydb_CONTENT.txt hydb_breakpoint.txt Total_UMBC_Synset.txt hydb_place.txt hydb
