############################################# content_word_extraction.py #############################################
content_word_extraction.py extracts all the content words from the situational tweets.
How to run: python content_word_extraction.py hydb_CLASSIFIED.txt hydb_place.txt hydb_CONTENT.txt
In this phase we extract basic content words (Numerals, Nouns, Verbs, Places).

Inputs:
        1. hydb_CLASSIFIED.txt => contains classified tweets with their confidence score [Date\tTweetID\tUserID\tTweet\tLabel\tConfidence score]
        2. hydb_place.txt => contains location information of Hyderabad
Output:
        hydb_CONTENT.txt => extract content words from tweets [Only situational tweets (Label = 1)  with confidence score >=0.8 are considered]


############################################# NSEMCOWTS.py ###########################################
NSEMCOWTS.py takes content files and produces the summary. Noun components and Verb components also are created by this code.
How to run: python NSEMCOWTS.py hydb_CONTENT.txt hydb_breakpoint.txt Total_UMBC_Synset.txt hydb_place.txt hydb
Inputs:
	1. hydb_CONTENT.txt => Contains details about tweets, content words present in tweets, length etc.
	2. hydb_breakpoint.txt => Contains the breakpoint (may ne multiple in different lines) at which the system should produce summaries (Tweet ID \t Line number \t summary word length). Due to fragmentation same tweet-id may be present in different (consecutive) lines. Hence format of this file is: Tweet ID \t Line number (at which summary is requires) \t Number of words (summary length)
	3. Total_UMBC_Synset.txt => Contains semantically related synonyms of a word
	4. hydb_place.txt => Contains location information of Hyderabad
	5. hydb => It is a keyword used to provide names to output files

NOTE: 

1. Path of the pos-tagger need to be adjusted for content_word_extraction.py [Line 29]
2. content_word_extraction.py considers situational tweets with classifier conidence score >= 0.8. If you want to change that modify Line 58.
3. This repo contains one sample file from Hyderabad blast
4. For new datasets users have to prepare their own synset file
5. Format of CONTENT file => index \t date \t tweet-id \t user-id \t tweet text \t content words \t all words \t length of tweet \t class of tweet \t classifier confidence score
6. summary_breakpoints folder contains two breakpoints at which summary is generated in the paper for each of the events. However, you can set any breakpoint based on your requirement.
