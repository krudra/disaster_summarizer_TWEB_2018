python content_word_extraction.py hydb_SITUATIONAL.txt hydb_place.txt hydb_CONTENT.txt
python NCOWTS.py hydb_CONTENT.txt hydb_breakpoint.txt hydb_place.txt hydb
